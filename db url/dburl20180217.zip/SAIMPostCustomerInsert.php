<?php
    include_once('dbConnect.php');
    setConnectionValue($_POST['dbName']);
    writeToLog("file: " . basename(__FILE__));
    
    
    
    if (isset ($_POST["postCustomerID"]) &&
        isset ($_POST["customerID"]) &&
        isset ($_POST["firstName"]) &&
        isset ($_POST["street1"]) &&
        isset ($_POST["postcode"]) &&
        isset ($_POST["country"]) &&
        isset ($_POST["telephone"]) &&
        isset ($_POST["lineID"]) &&
        isset ($_POST["facebookID"]) &&
        isset ($_POST["emailAddress"]) &&
        isset ($_POST["other"]) &&
        isset ($_POST["taxCustomerName"]) &&
        isset ($_POST["taxCustomerAddress"]) &&
        isset ($_POST["taxNo"]) &&
        isset ($_POST["receiptID"])
        )
    {
        $postCustomerID = $_POST["postCustomerID"];
        $customerID = $_POST["customerID"];
        $firstName = $_POST["firstName"];
        $street1 = $_POST["street1"];
        $postcode = $_POST["postcode"];
        $country = $_POST["country"];
        $telephone = $_POST["telephone"];
        $lineID = $_POST["lineID"];
        $facebookID = $_POST["facebookID"];
        $emailAddress = $_POST["emailAddress"];
        $other = $_POST["other"];
        $taxCustomerName = $_POST["taxCustomerName"];
        $taxCustomerAddress = $_POST["taxCustomerAddress"];
        $taxNo = $_POST["taxNo"];
        $receiptID = $_POST["receiptID"];
    } else {
        $postCustomerID = 0;
        $customerID = -1;
        $firstName = "";
        $street1 = "";
        $postcode = "";
        $country = "";
        $telephone = "";
        $lineID = "";
        $facebookID = "";
        $emailAddress = "";
        $other = "";
        $taxCustomerName = "";
        $taxCustomerAddress = "";
        $taxNo = "";
        $receiptID = "";
    }
    
    
    
    {
        // Check connection
        if (mysqli_connect_errno())
        {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }
        
        // Set autocommit to off
        mysqli_autocommit($con,FALSE);
        writeToLog("set auto commit to off");
        
        
        if($customerID == 0)
        {
            $sql = "select ifnull(max(customerID),0) MaxCustomerID from postCustomer";
            $selectedRow = getSelectedRow($sql);
            $maxCustomerID = $selectedRow[0]['MaxCustomerID'];
            $customerID = $maxCustomerID+1;
        }
        
        //query statement
        $sql = "INSERT INTO `PostCustomer`(`PostCustomerID`,`CustomerID`, `FirstName`, `Street1`, `Postcode`, `Country`, `Telephone`, LineID,FacebookID, EmailAddress, TaxCustomerName, TaxCustomerAddress, TaxNo, Other) VALUES ($postCustomerID,$customerID,'$firstName','$street1','$postcode','$country','$telephone','$lineID','$facebookID','$emailAddress','$taxCustomerName','$taxCustomerAddress','$taxNo','$other')";
        $ret = doQueryTask($con,$sql,$_POST["modifiedUser"]);
        if($ret != "")
        {
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        
        
        
        //select row ที่แก้ไข ขึ้นมาเก็บไว้
        $sql = "select * from postcustomer where `postCustomerID`=$postCustomerID";
        $selectedRow = getSelectedRow($sql);
        
        
        //broadcast ไป device token อื่น
        $type = 'tPostCustomer';
        $action = 'i';
        $ret = doPushNotificationTask($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
        if($ret != "")
        {
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        
        
        //broadcast ไปตัวเอง เพื่อ update ค่า customerID
        $type = 'tPostCustomer';
        $action = 'u';
        $modifiedDeviceToken = $_POST["modifiedDeviceToken"];
        
        
        //query statement, push to only old token device
        $sql = "insert into pushSync (DeviceToken, TableName, Action, Data, TimeSync) values ('$modifiedDeviceToken','$type','$action','" . json_encode($selectedRow, true) . "',now())";
        $ret = doQueryTask($con,$sql,$_POST["modifiedUser"]);
        if($ret != "")
        {
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        //----------
        
        
        //query statement
        $sql = "update customerreceipt set PostCustomerID = $postCustomerID where ReceiptID = $receiptID";
        $ret = doQueryTask($con,$sql,$_POST["modifiedUser"]);
        if($ret != "")
        {
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        
        
        
        //select row ที่แก้ไข ขึ้นมาเก็บไว้
        $sql = "select * from customerreceipt where ReceiptID = $receiptID";
        $selectedRow = getSelectedRow($sql);
        
        
        //broadcast ไป device token อื่น
        $type = 'tCustomerReceipt';
        $action = 'u';
        $ret = doPushNotificationTask($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
        if($ret != "")
        {
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        
        //-----
        
    }
    
    
    
    //do script successful
    sendPushNotificationToOtherDevices($_POST["modifiedDeviceToken"]);
    writeToLog("query commit, file: " . basename(__FILE__));
    mysqli_commit($con);
    mysqli_close($con);
    $response = array('status' => '1', 'sql' => $sql);
    
    
    echo json_encode($response);
    exit();
?>
